package com.example.library;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //Main Library Page
        Button create = (Button)findViewById(R.id.button);
        @SuppressLint("WrongViewCast") ImageButton home = (ImageButton)findViewById(R.id.hse);
        @SuppressLint("WrongViewCast") ImageButton lib = (ImageButton)findViewById(R.id.lib);
        @SuppressLint("WrongViewCast") ImageButton noti = (ImageButton)findViewById(R.id.noti);
        @SuppressLint("WrongViewCast") ImageButton user = (ImageButton)findViewById(R.id.user);

        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent fold = new Intent(MainActivity.this, cf.class);
                startActivity(fold);
            }
        });

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hse = new Intent(MainActivity.this,hm.class);
                startActivity(hse);
            }
        });

        lib.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent library = new Intent(MainActivity.this,MainActivity.class);
                startActivity(library);
            }
        });

        noti.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent notifications = new Intent(MainActivity.this,nt.class);
                startActivity(notifications);
            }
        });

        user.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent acct = new Intent(MainActivity.this,us.class);
                startActivity(acct);
            }
        });

    }
}
