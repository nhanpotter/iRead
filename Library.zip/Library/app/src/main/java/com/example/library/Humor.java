package com.example.library;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class Humor extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_humor);

        @SuppressLint("WrongViewCast") ImageButton home = (ImageButton)findViewById(R.id.hse);
        @SuppressLint("WrongViewCast") ImageButton lib = (ImageButton)findViewById(R.id.lib);
        @SuppressLint("WrongViewCast") ImageButton noti = (ImageButton)findViewById(R.id.noti);
        @SuppressLint("WrongViewCast") ImageButton user = (ImageButton)findViewById(R.id.user);

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hse = new Intent(Humor.this,hm.class);
                startActivity(hse);
            }
        });

        lib.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent library = new Intent(Humor.this,Humor.class);
                startActivity(library);
            }
        });

        noti.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent notifications = new Intent(Humor.this,nt.class);
                startActivity(notifications);
            }
        });

        user.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent acct = new Intent(Humor.this,us.class);
                startActivity(acct);
            }
        });
    }
}
